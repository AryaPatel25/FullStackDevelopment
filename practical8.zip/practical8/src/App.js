import './App.css';
import Counter from './counter';

function App() {
  return (
    <div className="App">
      <Counter />
    </div>
  );
}

export default App;
