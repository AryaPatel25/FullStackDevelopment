import React from "react";

export default function Home() {
  return (
    <div className="Home">
      <div className="header">
        <h1>Home</h1>
      </div>
      <div className="content">
        <p>
            This is the content of my home page
        </p>
      </div>
    </div>
  );
}
