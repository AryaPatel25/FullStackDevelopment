import React from "react";

export default function About() {
  return (
    <div className="About">
      <div className="header">
        <h1>About</h1>
      </div>
      <div className="content">
        <p>This is the content of my about page</p>
      </div>
    </div>
  );
}
