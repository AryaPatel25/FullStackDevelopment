import React from "react";

export default function Contact() {
  return (
    <div className="Contact">
      <div className="header">
        <h1>Contact</h1>
      </div>
      <div className="content">
        <p>This is the content of my contact page</p>
      </div>
    </div>
  );
}
