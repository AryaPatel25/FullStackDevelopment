import React, { useState } from "react";
import './ToDoList.css';
import { FaEdit } from 'react-icons/fa';
import { MdDelete } from 'react-icons/md';

function ToDoList() {
    const [tasks, setTasks] = useState([]);
    const [input, setInput] = useState("");

    const addTask = () => {
        if (input.trim() !== "") {
            setTasks([...tasks, input]);
            setInput("");
        } else {
            alert("Please enter a task.");
        }
    };

    const removeTask = (index) => {
        const newTasks = tasks.filter((_, i) => i !== index);
        setTasks(newTasks);
    };

    const editTask = (index) => {
        const newTask = prompt("Edit task:", tasks[index]);
        if (newTask !== null && newTask.trim() !== "") {
            const updatedTasks = tasks.map((task, i) => (i === index ? newTask : task));
            setTasks(updatedTasks);
        } else {
            alert("Please enter a valid task.");
        }
    };

    return (
        <div className="todo-list">
            <h1>Get Things Done !</h1>
            <div className="input-container">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") addTask(); }}
                    placeholder="What is the task today?"
                />
                <button onClick={addTask}>Add Task</button>
            </div>
            <ul>
                {tasks.map((task, index) => (
                    <li key={index}>
                        <span>{task}</span>
                        <div>
                            <button onClick={() => editTask(index)} className="icon-btn"><FaEdit /></button>
                            <button onClick={() => removeTask(index)} className="icon-btn"><MdDelete /></button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default ToDoList;
