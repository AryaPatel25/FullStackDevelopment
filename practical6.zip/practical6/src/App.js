import './App.css';
import ToDoList from './ToDoList.js';

function App() {
  return (
    <ToDoList />
  );
}

export default App;
